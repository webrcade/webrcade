// Minimal Anti-Aliased Nearest Neighbor (WebRcade / RA Web)
// Shimmer-free, dynamic resolution compatible
// MIT License

#define NOT(fl) (1.-fl)
#define YES(fl) fl

#if defined(VERTEX)

#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#define COMPAT_TEXTURE texture
#else
#define COMPAT_VARYING varying
#define COMPAT_ATTRIBUTE attribute
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 COLOR;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec4 COL0;
COMPAT_VARYING vec4 TEX0;

uniform mat4 MVPMatrix;
uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;

#define vTexCoord TEX0.xy
#define SourceSize vec4(TextureSize, 1.0 / TextureSize)
#define outsize vec4(OutputSize, 1.0 / OutputSize)

void main()
{
    gl_Position = MVPMatrix * VertexCoord;
    COL0 = COLOR;
    TEX0.xy = TexCoord.xy * TextureSize.xy / InputSize.xy;
}

#elif defined(FRAGMENT)

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#define COMPAT_PRECISION mediump
#else
#define COMPAT_PRECISION
#endif

uniform COMPAT_PRECISION vec2 OutputSize;
uniform COMPAT_PRECISION vec2 TextureSize;
uniform COMPAT_PRECISION vec2 InputSize;
uniform sampler2D Texture;
COMPAT_VARYING vec4 TEX0;

#define Source Texture
#define vTexCoord TEX0.xy
#define SourceSize vec4(TextureSize, 1.0 / TextureSize)
#define outsize vec4(OutputSize, 1.0 / OutputSize)

// minimal RA percent() logic for anti-aliased nearest neighbor
vec3 percent(float ssize, float tsize, float coord, float mod)
{
    float minfull = (coord*tsize - 0.49999)/tsize*ssize * mod;
    float maxfull = (coord*tsize + 0.49999)/tsize*ssize * mod;
    float realfull = floor(maxfull + 0.00001);

    if (minfull > realfull) {
        return vec3(1.0, (realfull + 0.49999)/ssize, (realfull + 0.49999)/ssize);
    }

    return vec3(1.0, (realfull - 0.49999)/ssize, (realfull + 0.49999)/ssize);
}

void main()
{
    vec2 viewportSize = outsize.xy;
    vec2 gameCoord = vTexCoord;

    // compute Y interpolation using proper RA method
    vec3 ystuff = percent(SourceSize.y, viewportSize.y, gameCoord.y, InputSize.y / TextureSize.y);

    // sample texture at snapped vertical position
    vec2 uv = vec2(gameCoord.x, ystuff.z);
    FragColor = COMPAT_TEXTURE(Source, uv);
}
#endif
